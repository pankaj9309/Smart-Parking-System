<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
   $phone = $_POST['phone'];
    
       include 'dbconnect.php';
            
                   
                 $SQL3= "select user_id,fullname,phone,username,password from user_details where phone='".$phone."'";
                 $ava=mysqli_query($con,$SQL3);

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Smart Parking System</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/creative.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">

                <a class="navbar-brand page-scroll" href="#page-top" style="float:left;">Smart Parking System</a>
                            
            </div>
        </br>
            <div style="float:right">
                  <a href="#phone" class="btn btn-info" >Search</a>
                  <a href="deleteuser.php?id=all" class="btn btn-info" >Delete All</a>
                  <a href="users.php" class="btn btn-info" >Show All</a>
                    <a href="logout.php" class="btn btn-info" >Log Out</a>
                  
               </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
   </br>
</br>
</br>
   <div class="header-content">
   <table class="table table-hover table-bordered" style="border:4px ridge;color:black;">
                <tr>
                          <th class="info"> User Id </th>
                          <th class="info"> Full Name </th>

                          <th class="info"> Phone</th> 
                          <th class="info"> UserName </th> 
                          <th class="info"> Password</th> 
                          <th class="info"> Operation</th>
                          
                </tr> 
                        
                    <?php


                     while ($db_field3 = mysqli_fetch_assoc($ava))
                            {
                               
                                echo "<tr>";
                                echo "<td>".$db_field3['user_id']."</td>";
                                 echo "<td>".$db_field3['fullname']."</td>";
                          
                                echo "<td>".$db_field3['phone']."</td>";
                                echo "<td>".$db_field3['username']."</td>";
                               echo "<td>".$db_field3['password']."</td>";
                               echo "<td><a href='deleteuser.php?id=".$db_field3['user_id']."'>delete</a>";
                                echo "</tr>";
                            }

                       
                    ?>

            </table>

   </div>
    </br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br>
    <div class="page-header text-center">
                <h1 style="color:black; font-size:2em; float:center">Search User</h1>
            </div>
   <div id="search">
    <form class="form-horizontal" role="form" method="post" action="searchuser.php">
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Phone:</label>
      <div class="col-sm-6">
        <input type="text" class="form-control" id="email" name="phone" placeholder="Enter Phone Number">
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-6">
        <button type="submit" class="btn btn-info">Submit</button>
      </div>
    </div>
  </form>
</div>    
 

     <!--  <header>
        <div class="header-content">
            <div class="header-content-inner">
                <h1 id="homeHeading">Here You Can Park </h1>
                <hr>
                <p>Automatic smart parking system which is simple, economic and provides effective solution to reduce carbon footprints in the atmosphere!</p>
                <a href="#about" class="btn btn-primary btn-xl page-scroll">Find Out More</a>
            </div>
        </div>
    </header>
 -->
</body>
</html>
	     