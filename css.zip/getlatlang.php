<?php 
 include('dbconnect.php');
//If a post request is detected 
 
if($_SERVER['REQUEST_METHOD']=='POST'){
 
 //Getting the username and otp  
 $request = $_POST['latlang'];
 
 $SQL3= "select parking_name,latitude,longitude from parking_lot_details ";
 $result=' ';
                 $ava=mysqli_query($con,$SQL3);
                           while ($db_field3 = mysqli_fetch_assoc($ava))
                            {
                               
                                $result=$result.$db_field3['latitude'].','.$db_field3['longitude'].','.$db_field3['parking_name'].':';
                             }
                             
                             echo $result;
                             mysqli_close($con);
}
