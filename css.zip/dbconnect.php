<?php
$hostname="192.185.129.7";
$db="wcewle8w_finalsps";
$username="wcewle8w_shubham";
$password="shubham123";
$con=@mysqli_connect($hostname,$username,$password,$db)or trigger_error(mysql_error(),E_USER_ERROR);


mysql_select_db($db,$con);

?>