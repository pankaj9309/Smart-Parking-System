<?php 
 include('dbconnect.php');
//If a post request is detected 
 
if($_SERVER['REQUEST_METHOD']=='POST'){
 
 //Getting the username and otp  
 $username = $_POST['username'];
 $password = $_POST['password'];
 

    //Importing the dbConnect script 
 
 
 //Creating an SQL to fetch the otp from the table 
 $sql = "SELECT count(*) as ct FROM user_details WHERE username = '$username' and password='$password'";
 
 //Getting the result array from database 
 $result = mysqli_fetch_array(mysqli_query($con,$sql));
 
 //Getting the otp from the array 
 $datafound = $result['ct'];
 
 //If the otp given is equal to otp fetched from database 
 if($datafound==1){
 //Creating an sql query to update the column verified to 1 for the specified user 
 echo 'success';
 }else{
 //displaying failure 
 echo 'failure';
 }

 
 //Closing the database 
 mysqli_close($con);
}
