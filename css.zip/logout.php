<?php
        session_start();
        session_destroy();
?>
<html>

    <body>
        <meta http-equiv="refresh"
 content="1;url=index.html"/>
        
    </body>

</html>