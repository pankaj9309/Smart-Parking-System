<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
   $user = $_POST['uname'];
	      $pass = $_POST['pass'];
    	  if(($user == "Admin") AND ($pass == "root"))
			{
				session_start();
				$_SESSION['uname'] = $user;
				$flag=1;
				header('location: users.php');
			}
              else
               { 
             
    
                            echo "<script type='text/javascript'>
                               alert('User Name or Password is incorrect....try again!!!')
                                window.history.back();
                                </script>";
    
                }			
}
?>
