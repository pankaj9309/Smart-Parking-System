<?php

    include 'dbconnect.php';
       mysql_select_db($db,$con);
        if(isset($_POST['submit']))
        {
            $parkingname=mysqli_real_escape_string($con,$_POST['parkingname']);
            $contact=mysqli_real_escape_string($con,$_POST['contact']);
            $address=mysqli_real_escape_string($con,$_POST['address']);
            $username=mysqli_real_escape_string($con,$_POST['uname']);
            $password=mysqli_real_escape_string($con,$_POST['pass']);
            

	$coordinates = file_get_contents('http://maps.googleapis.com/maps/api/geocode/json?address=' . urlencode($address) . '&sensor=true');
	$coordinates = json_decode($coordinates);
 
	$latitude=$coordinates->results[0]->geometry->location->lat;
	$longitude= $coordinates->results[0]->geometry->location->lng;
 
            
             $sql="INSERT into parking_lot_details (parking_name,contact_no,parking_address,latitude,longitude,loginname,password,status)values('$parkingname','$contact','$address','$latitude','$longitude','$username','$password','Available')";
             ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


            
            if (mysqli_query($con, $sql)) 
           {
             echo "New record created successfully";
                header('location:parkinglotlogin.html');
            
           }
          
         else
        {  
             
                 echo "mysqli_query($con, $sql)";
        }
      }

?> 