<?php
           include 'dbconnect.php';
            
            session_start();
                          
                 $SQL3= "insert into sensordata(data) values('fi')";
                 $ava=mysqli_query($con,$SQL3);


?>