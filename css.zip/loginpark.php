<?php
session_start();
$user = "";
$pass = "";
$msg = "";
$flag=0;
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
  include 'dbconnect.php';
    
  $user = $_POST['uname'];
  $pass = $_POST['pass'];
            
    
  $user = htmlspecialchars($user);
  $pass = htmlspecialchars($pass);
  
  $SQL = "SELECT * FROM parking_lot_details where loginname='$user' and password='$pass'";
  $count="select count(*) as cp from (SELECT * FROM parking_lot_details where loginname='$user' and password='$pass')as temp";
  $result = mysqli_query($con, $SQL);
    $c1 = mysqli_fetch_assoc(mysqli_query($con,$count));
   
         if($c1['cp']>0)
         {
                  session_start();
        $_SESSION['uname'] = $user;
        $flag=1;
        header('location: parkinglothome.php');
  
         }
         else
         {
    
                            echo "<script type='text/javascript'>
                               alert('User Name or Password is incorrect....try again!!!')
                                window.history.back();
                                </script>";
         }
    }

?>
