<?php
    echo $_GET["t"];
    ?>